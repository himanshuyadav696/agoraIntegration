# README #

This README would normally document whatever steps are necessary to get your application up and running.

1. FAQ, About us, Privacy policy menu using. [AboutMenuFragment]
 

