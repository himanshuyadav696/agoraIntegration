package com.app.agoraintegration.ui.videocall
import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.util.Log
import android.view.SurfaceView
import android.view.View
import android.widget.ImageView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.app.agoraintegration.R
import com.app.agoraintegration.databinding.ActivityVideocallBinding
import io.agora.rtc2.*
import io.agora.rtc2.video.VideoCanvas


class videoCallActivity : AppCompatActivity() {
    private lateinit var binding:ActivityVideocallBinding
    private val PERMISSION_REQ_ID = 22
    private val appId = "12786a0b3dd744f58c0119ecd0771db5"
    private val channelName = "Yadav"
    private val token = "007eJxTYLC/nDFHsGK1xfrZa7+vdWGfvqaXWdrrNmvgIuV582IDNosrMBgamVuYJRokGaekmJuYpJlaJBsYGlqmJqcYmJsbpiSZnlspkdIQyMjwQFCXkZEBAkF8VobIxJTEMgYGAPRKHco="
    private val uid = 0
    private var isJoined = false
    private var remoteUid = 0
    private var agoraEngine: RtcEngine? = null
    private var localSurfaceView: SurfaceView? = null
    private var remoteSurfaceView: SurfaceView? = null

    private val REQUESTED_PERMISSIONS = arrayOf(
        Manifest.permission.RECORD_AUDIO,
        Manifest.permission.CAMERA
    )

    private fun checkSelfPermission(): Boolean {
        return !(ContextCompat.checkSelfPermission(
            this,
            REQUESTED_PERMISSIONS[0]
        ) != PackageManager.PERMISSION_GRANTED ||
                ContextCompat.checkSelfPermission(
                    this,
                    REQUESTED_PERMISSIONS[1]
                ) != PackageManager.PERMISSION_GRANTED)
    }

    private fun showMessage(message:String){
        runOnUiThread {
            Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
        }
    }

    private fun setupVideoSDKEngine() {
        try {
            val config = RtcEngineConfig()
            config.mContext = baseContext
            config.mAppId = appId
            config.mEventHandler = mRtcEventHandler
            agoraEngine = RtcEngine.create(config)
            // By default, the video module is disabled, call enableVideo to enable it.
            agoraEngine!!.enableVideo()
        } catch (e: Exception) {
            showMessage(e.toString())
        }
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityVideocallBinding.inflate(layoutInflater)
        setContentView(binding.root)
        if (!checkSelfPermission()) {
            ActivityCompat.requestPermissions(this, REQUESTED_PERMISSIONS, PERMISSION_REQ_ID)
        }
        setupVideoSDKEngine()
        binding.apply {
            btnLeaveCall.setOnClickListener {
                leaveCall()
            }
            muteActionFab.setOnClickListener {
                localMutedClicked(binding.muteActionFab)
            }
            icSwitch.setOnClickListener {
                localSwitchCamera(binding.icSwitch)
            }
            localVideoActionFab.setOnClickListener {
                localVideoOff(binding.localVideoActionFab)
            }

        }

        joinCall()
    }

    private fun leaveCall() {
        if (!isJoined) {
            showMessage("Join a channel first")
        } else {
            agoraEngine?.leaveChannel()
            showMessage("You left the channel")
            remoteSurfaceView?.visibility = View.GONE
            localSurfaceView?.visibility = View.GONE
            isJoined = false
            finish()
        }
    }

    private fun joinCall() {
        if (checkSelfPermission()) {
            val options = ChannelMediaOptions()
            options.channelProfile = Constants.CHANNEL_PROFILE_COMMUNICATION
            options.clientRoleType = Constants.CLIENT_ROLE_BROADCASTER
            setupLocalVideo()
            localSurfaceView!!.visibility = View.VISIBLE
            agoraEngine!!.startPreview()
            agoraEngine!!.joinChannel(token, channelName, uid, options)
        } else {
            Toast.makeText(applicationContext, "Permissions was not granted", Toast.LENGTH_SHORT)
                .show()
        }
    }

    private val mRtcEventHandler: IRtcEngineEventHandler = object : IRtcEngineEventHandler() {
        override fun onUserJoined(uid: Int, elapsed: Int) {
            showMessage("Remote user joined $uid")
            remoteUid = uid
            runOnUiThread {
                binding.remoteUser.visibility = View.VISIBLE
                setupRemoteVideo(uid) }
        }
        override fun onJoinChannelSuccess(channel: String, uid: Int, elapsed: Int) {
            isJoined = true
            showMessage("Joined Channel $channel")
        }

        override fun onUserOffline(uid: Int, reason: Int) {
            showMessage("Remote user offline $uid $reason")
            runOnUiThread { remoteSurfaceView!!.visibility = View.GONE
                binding.remoteUser.visibility = View.GONE}
        }

        override fun onUserMuteAudio(uid: Int, muted: Boolean) {
            super.onUserMuteAudio(uid, muted)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        agoraEngine!!.stopPreview()
        agoraEngine!!.leaveChannel()

        // Destroy the engine in a sub-thread to avoid congestion
        Thread {
            RtcEngine.destroy()
            agoraEngine = null
        }.start()
    }

    private fun setupRemoteVideo(uid: Int) {
        remoteSurfaceView = SurfaceView(baseContext)
        remoteSurfaceView!!.setZOrderMediaOverlay(true)
        binding.remoteUser.addView(remoteSurfaceView)
        agoraEngine!!.setupRemoteVideo(
            VideoCanvas(
                remoteSurfaceView,
                VideoCanvas.RENDER_MODE_ADAPTIVE,
                uid
            )
        )
        remoteSurfaceView!!.visibility = View.VISIBLE
    }

    private fun setupLocalVideo() {
        localSurfaceView = SurfaceView(baseContext)
        binding.localUser.addView(localSurfaceView)
        agoraEngine!!.setupLocalVideo(
            VideoCanvas(
                localSurfaceView,
                VideoCanvas.RENDER_MODE_HIDDEN,
                0
            )
        )
    }

    private fun localMutedClicked(view: View){
        val iv = view as ImageView
        if(iv.isSelected){
            iv.isSelected = false
            iv.clearColorFilter()
        }
        else{
            iv.isSelected = true
            iv.setColorFilter(resources.getColor(R.color.colorPrimary))
        }
        agoraEngine!!.muteLocalAudioStream(iv.isSelected)
    }

    private fun localSwitchCamera(view: View){
        val iv = view as ImageView
        agoraEngine?.switchCamera()
    }
    private fun localVideoOff(view: View){
        val iv = view as ImageView
        if(iv.isSelected){
            iv.isSelected = false
            iv.clearColorFilter()
        }
        else{
            iv.isSelected = true
            iv.setColorFilter(resources.getColor(R.color.colorPrimary))
        }
        agoraEngine!!.muteLocalVideoStream(iv.isSelected)
    }

}