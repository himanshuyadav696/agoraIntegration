package com.app.agoraintegration.utils

class AppConstants {
        companion object {
            val MOBILE_NUMBER="MOBILE_NUMBER"
            val COUNTRY_CODE="COUNTRY_CODE"
            const val BUCKET_ID="delightbucket"
            val IS_LOGIN = "IS_LOGIN"
        }

    interface USER_PREF {
        companion object {
            const val IS_LOGIN = "IS_LOGIN"
        }
    }
}