package com.app.agoraintegration.utils.lang

interface OnLocaleChangedListener {
    fun onBeforeLocaleChanged()

    fun onAfterLocaleChanged()
}
