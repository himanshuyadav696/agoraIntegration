package com.app.agoraintegration.core.network

import android.os.Parcelable
import androidx.annotation.Keep
import kotlinx.android.parcel.Parcelize

@Keep
@Parcelize
data class ApiResponse(
    val response: ResponseModel,
    val error: Error? = null,
) : Parcelable

@Keep
@Parcelize
data class ResponseModel(
    val data: Data? = null,
    val message: MessageModel? = null
) : Parcelable

@Keep
@Parcelize
data class Error(
    val errorCode: Int = 0,
    val code: Int = 0,
    val message: String? = null
) : Parcelable

@Keep
@Parcelize
data class Data(
    val customerId: String? = null,
    val fullName: String? = null,
    val mobileNo: String? = null,
    val email: String? = null,
    val refresh: String? = null,
    val jwtToken: String? = null,

) : Parcelable

@Keep
@Parcelize
data class MessageModel(
    val success: Boolean? = null,
    val successCode: Int? = null,
    val statusCode: Int? = null,
    val successMessage: String? = null
) : Parcelable


@Keep
@Parcelize
data class LanguageModel(
    var lang: String? = null,
    var code: String = "en",
    var isChecked: Boolean = false,
) : Parcelable






