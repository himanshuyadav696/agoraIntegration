package com.app.agoraintegration.utils

import android.graphics.drawable.Drawable
import android.view.View
import android.widget.ImageView
import android.widget.TextView
import com.bumptech.glide.Glide
import com.bumptech.glide.load.DataSource
import com.bumptech.glide.load.engine.DiskCacheStrategy
import com.bumptech.glide.load.engine.GlideException
import com.bumptech.glide.request.RequestListener
import com.bumptech.glide.request.RequestOptions
import com.bumptech.glide.request.target.Target


fun setLikeCount(view: TextView, likeCount: Long) {
    if (likeCount <= 0) {
        //view.visibility = View.GONE
        view.text = "0"

    } else {
        view.text =
            "${AppUtils.getProcessedLikeCount(likeCount)}"
    }

}

fun setCount(view: TextView, likeCount: Long) {
    if (likeCount <= 0) {
        view.text = "0"
    } else {
        view.text = AppUtils.getProcessedLikeCount(likeCount)
    }

}


/*fun setCommentCount(view: TextView, likeCount: Long) {
    if (likeCount <= 0) {
        view.text = "0 ${view.resources.getString(R.string.comment)}"
        // view.visibility = View.GONE
    } else {
        val count = AppUtils.getProcessedLikeCount(likeCount)
        if (!count.isNullOrEmpty()) {
            view.text = "$count ${view.resources.getString(R.string.comments)}"

        }
    }
}*/

fun setEarningPoint(view: TextView, pts: String?) {
    if (!pts.isNullOrEmpty()) {

        view.text = "$pts pts"
    }
}


fun setEarningPoint(view: TextView, pts: Long?) {
    if (pts != null) {
        view.text = "$pts pts"
    } else {
        view.text = "0 pts"
    }
}

fun setPoints(view: TextView, pts: Long?) {
    if (pts != null) {
        view.text = "$pts points"
    } else {
        view.text = "0 point"
    }
}

/*fun setFollowers(view: TextView, pts: Long?) {
    if (pts != null && pts >= 0) {
        val count = AppUtils.getProcessedLikeCount(pts)

        view.text = "$count ${view.context.resources.getString(R.string.followers)}"
    }
}*/


fun setLongToText(view: TextView, pts: Long?) {
    if (pts != null && pts > 0) {
        val count = AppUtils.getProcessedLikeCount(pts)

        view.text = "$count"
    } else {
        view.text = "0"
    }
}

fun setProfile(view: ImageView, url: String?) {
    if (!url.isNullOrEmpty()) {

        val requestOption = RequestOptions()
        //  requestOption.error(R.drawable.white_background)
        //requestOption.placeholder(R.drawable.white_background)
        requestOption.diskCacheStrategy(DiskCacheStrategy.ALL)
        Glide.with(view.context)
            .load(url)
            .circleCrop()
            .apply(requestOption)
            .listener(object : RequestListener<Drawable> {
                override fun onLoadFailed(
                    e: GlideException?,
                    model: Any?,
                    target: Target<Drawable>?,
                    isFirstResource: Boolean
                ): Boolean {
                    return false
                }

                override fun onResourceReady(
                    resource: Drawable?,
                    model: Any?,
                    target: Target<Drawable>?,
                    dataSource: DataSource?,
                    isFirstResource: Boolean
                ): Boolean {
                    return false
                }

            }).into(view)

    }
}


//ivPhoto,
fun View.setImage(view: ImageView, url: String?) {
    if (!url.isNullOrEmpty()) {
        val requestOption = RequestOptions()
        //  requestOption.error(R.drawable.white_background)
        //requestOption.placeholder(R.drawable.white_background)
        val t = requestOption.diskCacheStrategy(DiskCacheStrategy.ALL)
        Glide.with(this)
            .load(url)
            .apply(t)
            .listener(object : RequestListener<Drawable> {
                override fun onLoadFailed(
                    e: GlideException?,
                    model: Any?,
                    target: Target<Drawable>?,
                    isFirstResource: Boolean
                ): Boolean {
                    return false
                }

                override fun onResourceReady(
                    resource: Drawable?,
                    model: Any?,
                    target: Target<Drawable>?,
                    dataSource: DataSource?,
                    isFirstResource: Boolean
                ): Boolean {
                    return false
                }

            }).into(view)

    }
    }
fun setProfileImage(view: ImageView, url: String?) {
    if (!url.isNullOrEmpty()) {

        val requestOption = RequestOptions()
        //  requestOption.error(R.drawable.ic_user)
      //  requestOption.placeholder(R.drawable.ic_user)
        val t = requestOption.diskCacheStrategy(DiskCacheStrategy.ALL)
        Glide.with(view.context)
            .load(url)
            .apply(requestOption)
            .listener(object : RequestListener<Drawable> {
                override fun onLoadFailed(
                    e: GlideException?,
                    model: Any?,
                    target: Target<Drawable>?,
                    isFirstResource: Boolean
                ): Boolean {
                    return false
                }

                override fun onResourceReady(
                    resource: Drawable?,
                    model: Any?,
                    target: Target<Drawable>?,
                    dataSource: DataSource?,
                    isFirstResource: Boolean
                ): Boolean {
                    return false
                }

            }).into(view)

    }
}