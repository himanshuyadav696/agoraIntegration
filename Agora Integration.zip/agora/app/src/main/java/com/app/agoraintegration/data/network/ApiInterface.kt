package com.app.agoraintegration.data.network
import com.app.agoraintegration.data.sharedPrefs.PrefsHelper
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory


interface ApiInterface {

    companion object {
        private const val BASE_URL = "http://delight.apponward.com/api/v2/"
        private const val AUTH = "Authorization"

        fun create(prefsHelper: PrefsHelper): ApiInterface {

             var token = "Bearer ${prefsHelper.token}"

            val okHttpClient = OkHttpClient.Builder().apply {

                addInterceptor {

                    val request: Request.Builder = it.request().newBuilder()
                    request.header("Content-Type", "application/json")
                    request.header("Accept", "application/json")
                    request.header(AUTH, token)
                    val response = it.proceed(request.build())

                    //todo change code expiry token
                   /* if (response.code==201){
                        val intent =Intent(appCtx,SignInActivity::class.java)
                         appCtx.startActivity(intent)
                        //appCtx.startActivity()
                    }
*/

                    response
                }


               /* if (BuildConfig.DEBUG) {
                    addInterceptor(OkHttpProfilerInterceptor())
                }*/
                addNetworkInterceptor(
                    HttpLoggingInterceptor(
                        object : HttpLoggingInterceptor.Logger {
                            override fun log(message: String) {
                                println(": $message")
                            }
                        }
                    ).apply { level = HttpLoggingInterceptor.Level.BODY }
                )

            }.build()

            return Retrofit.Builder()
                .baseUrl(BASE_URL)
                .client(okHttpClient)
                .addConverterFactory(MoshiConverterFactory.create())
                .build()
                .create(ApiInterface::class.java)
        }
    }
}