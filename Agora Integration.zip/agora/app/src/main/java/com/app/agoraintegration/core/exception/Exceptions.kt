package com.app.agoraintegration.core.exception

import java.io.IOException

class NoConnectionException : IOException("Not Connected")
